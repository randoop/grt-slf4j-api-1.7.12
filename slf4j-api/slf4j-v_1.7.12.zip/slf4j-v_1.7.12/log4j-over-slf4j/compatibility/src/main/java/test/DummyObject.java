package test;

public class DummyObject {

  public String toString() {
    return "dummy";
  }
}
